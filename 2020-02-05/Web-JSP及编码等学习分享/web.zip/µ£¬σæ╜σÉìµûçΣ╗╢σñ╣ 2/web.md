# JSP

## 结构及处理过程

* 结构      ![img](https://www.runoob.com/wp-content/uploads/2014/01/jsp-arch.jpg)
* 处理
  * 浏览器发送HTTP给服务器
  * web服务器识别为对JSP的请求，并传递给JSP引擎
  * JSP引擎载入JSP文件，并转化为Servlet(将所有文本该用print(),JSP元素转化为Java代码)
  * JSP引擎将Servlet编译为可执行类
  * web服务器调用Servlet并执行
  * web服务器将静态HTML网页的形式将HTTP response返回
  * web服务器处理HTTP response中动态产生的HTML网页
  * ![image-20200205200248827](/Users/lorelei/Library/Application Support/typora-user-images/image-20200205200248827.png)

## 生命周期

* 编译阶段: 生成servlet源文件
* 初始化阶段: 加载与JSP对应的servlet类并创建实例
* 执行阶段: 调用与JSP对应的servlet实力的服务方法
* 销毁阶段: 调用与JSP对应的servlet实例的销毁方法

## 基本语法格式

<% 代码片段 %> 

```HTML
<html>
<head><title>Hello World</title></head>
<body>
Hello World!<br/>
<%
out.println("Your IP address is " + request.getRemoteAddr());
%>
</body>
</html>
```

