#堆的入门级题目
---------
##堆的知识
>**堆和栈是两个相似的概念,一般来说栈是由程序自动分配的,而堆是由用户手动分配的,**
**例如C语言中调用malloc()来申请chunk.而且堆是从低地址向高地址生长的.**
###堆的结构
![heap](heapstruct.jpg)

~~因为malloc实现分配的内存空间是8字节对齐的，所以size的低3位其实没用，就取其中一位,~~
~~用来标志前一个chunk是否被释放即PREV_INUSE位。当前一chunk释放，PREV_INUSE位置0，否则置1~~
###堆分配机制
当一个chunk被释放时，还有一件事情要做，就是检查相邻chunk的是否处于释放状态，如果相邻chunk空闲的话，就会进行chunk合并操作。
**free()会调用一个unlink宏来执行合并操作：**
```
#define unlink(P, BK, FD) {                      \
    FD = P->fd;                                    \
    BK = P->bk;                                    \
    FD->bk = BK;                                   \
    BK->fd = FD;                                   \
}
```

---------
##分析程序
###查看文件信息
>\$ file babyfengshui 
babyfengshui: ELF 32-bit LSB executable, Intel 80386, version 1 (SYSV), dynamically linked, interpreter /lib/ld-, for GNU/Linux 2.6.32, BuildID[sha1]=cecdaee24200fe5bbd3d34b30404961ca49067c6, stripped
$ checksec babyfengshui 
Arch:     i386-32-little
RELRO:    Partial RELRO
Stack:    Canary found
NX:       NX enabled
PIE:      No PIE (0x8048000)
###运行一下(典型的菜单题)
![run](run.jpg)
###查看程序逻辑
![partly_logic](logic.jpg)
**(程序的保护机制)**
![defense](defense.jpg)

------------------------
##如何绕过
(plt和got表)
![plt&got](pltgot.jpg)


![](chunks.jpg)

