# PHP中IP获取、伪造及应用

## 三个扩展头部

- **X_FORWARDED_FOR（XFF）**
- **HTTP_CLIENT_IP（HCI）**
- **REMOTE_ADDR（RA）**

先说一下大部分知名的PHP软件怎么实现获取IP：

```php
if(getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) { $onlineip = getenv('HTTP_CLIENT_IP'); } elseif(getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) { $onlineip = getenv('HTTP_X_FORWARDED_FOR'); } elseif(getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) { $onlineip = getenv('REMOTE_ADDR'); } elseif(isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) { $onlineip = $_SERVER['REMOTE_ADDR']; } 
//getenv函数主要用来获取一个环境变量的值
//PHP strcasecmp() 函数比较两个字符串。该函数返回：等于0 -> 则 两个字符串相等；小于0 -> 则 string1 小于 string2；大于0 -> 则 string1 大于 string2
```

开门见山：

- XFF有个缺陷可以使客户端伪造任意IP，当然包括字符串，但是对其他两个函数就不行了。
- HCI可以更改IP，仅限数字。
- 而RA获得的IP，无法修改。
- RA是由`nginx`传递给 php 的参数，所以就是当前`nginx`直接通信的客户端的 IP ，而我们无法插手。所以一旦对方使用了`REMOTE_ADDR`函数来获取IP，那就没办法了。不过不要紧，一共3个头部，2个头部可以伪造，我们还是有很多机会学习新知识~~（干坏事）~~的。
- 不过值得庆幸的是`nginx`等反向代理服务器的时候，是必须使用`X-Forward-For`来获取用户IP地址的（此时`Remote Address`是`nginx`的地址），因为此时`X-Forward-For`中的地址是由`nginx`写入的，而`nginx`是可信任的。

******

目前很多主流优先使用**X_FORWARDED_FOR（XFF）**获取IP（明治有缺陷还用，肯定都知道对输入的敏感词有过滤），那我们就主要介绍一下XFF。

## XFF

X-Forwarded-For(XFF)是用来识别通过HTTP代理或负载均衡方式连接到Web服务器的客户端最原始的IP地址的HTTP请求头字段。 Squid 缓存代理服务器的开发人员最早引入了这一HTTP头字段，并由IETF在Forwarded-For HTTP头字段标准化草案中正式提出。
这一HTTP头一般格式如下:

```
X-Forwarded-For: client1, proxy1, proxy2
```

其中的值通过一个 `逗号+空格` 把多个IP地址区分开, 最左边(client1)是最原始客户端的IP地址, 代理服务器每成功收到一个请求，就把请求来源IP地址添加到右边。

******

代理的大体框架：

```
客户端=>正向代理=>透明代理=>服务器反向代理=>Web服务器
```

******

我们都知道，Http是基于TCP/IP的协议，我们为什么不可以从传输层的socket获得我们所需要源用户ip呢？其实Http已经从socket取得所需要IP，但是这个IP并一定是我们所需要的真实IP，来看看下面的两个例子。

![image-20210130004104807](pic/image-20210130004104807.png)

在第一个例子中，我们可以看出来，客户端是直接连接的服务器，则获取到的IP即为真实的client ip地址信息。

![image-20210130004139342](pic/image-20210130004139342.png)

若通过代理, 则直连的ip会被代理服务器的ip所替代。通过两个例子中的对比, 我们可以清楚的观察到, 在反向代理模式下, **客户端的socket已经被nginx的socket所代替**。若还是按默认的方式`(request.remote_ip)`来获取客户端ip, 将失去意义。

nginx是7层代理, 不是4层代理。7层代理的意思我们只能从修改第七层的包信息，因此不可能在tcp/ip这层做手脚. 只能在http/https这个应用层协议中做文章。nginx的策略是: 往http/https请求中, 添加额外的header信息, 以此来完成真实客户端ip的信息传递。下面是nginx中的一些内部变量的定义：

```
$remote_addr #来自对端socket的ip地址
$remote_port #来自对端socket的port信息
$proxy_add_x_forwarded_for #http/https请求流经的所有代理的ip
```

在nginx配置中, 需要在location标签下添加如下项:

```
proxy_set_header Host $host;
proxy_set_header X-Real-IP $remote_addr;
proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
```

X-Real-IP我们很容易可以理解了，就是取得和我们服务器建立tcp链接的ip地址。这里就需要X-Forwarded-For来记录ip的信息了。
标准格式如下：`X-Forwarded-For: client1, proxy1, proxy2`。（终于讲回来了）

从标准格式可以看出，X-Forwarded-For头信息可以有多个，中间用逗号分隔，第一项为真实的客户端ip，剩下的就是曾经经过的代理或负载均衡的ip地址，经过几个就会出现几个。

光从定义来看, X-Forward-For只是记录了, 来自客户端所流经的代理服务器的链路路程, 好像没啥作用。获取真实IP, 通过获取设定的X-Real-IP即可。当nginx只有一层代理，这种方案是可行的。

但是在现实的web架构中, 存在多层代理服务器时, 使用X-Real-IP会丢失真实的客户端IP, 而X-Forward-For依旧为你保留了真实的客户端IP, 这也为什么后端web server从X-Forward-For中获取client ip, 而不是从X-Real-IP中获取的本质原因。

![image-20210130004819591](pic/image-20210130004819591.png)

因此，一般来说，我们要获得客户端地址，直接从 X-Forwarded-For 拿到第一个 IP 地址即可。一般代码如下：

```java
String ips = request.getHeader("X-Forwarded-For");
```

******

## 利用XFF伪造IP

1. Firefox的插件：X-Forwarded-For Header

   简单好用，不过这个新版本不能输入字符串，我不是很喜欢~~（那我怎么干坏事）~~

   ![image-20210130010512647](pic/image-20210130010512647.png)

   ![image-20210130012219440](pic/image-20210130012219440.png)

   当实践的网页用的是XFF查看IP地址时，便可以伪造IP。

   ![image-20210130010652147](pic/image-20210130010652147.png)

2. 万能的BurpSuite

   ![image-20210130011248179](pic/image-20210130011248179.png)

   ![image-20210130011642255](pic/image-20210130011642255.png)

   看上下IP对比，上面是BP修改的IP，下面是插件之前改的IP，说明网页是根据数据包中的XFF值来确定IP的~~（那不是废话）~~。而且，BP可以直接构建攻击代码。（后面会给出）






******

## XFF可以做的好事

1. 本职工作——伪造真实IP来使用需要真实IP才能使用的功能，比如使用大量的真实IP刷票啥的。

   - 因为如果使用大量的真实IP刷票的话，首先无论是时间成本还是硬件成本都很高，而且效率低下，同时由于每个ISP的IP分配池都是有限的，当你所在的IP池容量较小时，你能够分配的IP也是很少的，因此可能无法大量刷票，这个也是潜在的风险。
   - 而在TCP/IP层级别的伪造是个难题，不易实现。
   - 而通过使用HTTP的X-Forwarded-For头可以成功欺骗多数应用程序，而原理就是开头的大多数程序都会使用的代码，更主要的是现在的网络中代理很常见，而使用的代理的话，XFF可以找到客户端的真实IP。

2. CTF中的利用

   1. CTF中信息获取

      这个比较简单，比如它规定了管理员的IP地址，只有管理员才能显示flag，一种解题方式是如果存在XSS漏洞的话构造XSS代码盗取管理员cookie，还有一种就是利用XFF函数伪造管理员IP，直接查看flag。
      因为比较简单，在这就不详写了，给了一个解题wp，看一下类似题就行了——[攻防世界XCTF Writeup 之xff_referer](https://blog.csdn.net/qq_26012889/article/details/102773547)

   2. CTF中的XSS
      (因为我之前做到过XSS的题，内容就是在XFF中构造一串JavaScript代码获取flag的，但我现在不记得那个题目的来源了，就先找一个成功`alert`的实例说明XFF中可以执行JavaScript代码)

      <img src="pic/1-1ZS00Z93S04.png" alt="1" style="zoom:150%;" />

      ```
      把X-Forwarded-For: 192.168.1.2修改为：X-Forwarded-For: "/><script>alert('Power_liu')</script>script>
      ```

      <img src="pic/1-1ZS0091000135.png" alt="2" style="zoom:150%;" />

      ![3](pic/1-1ZS00910214N.png)

      这样就成功触发了XSS-Payload弹窗

   3. CTF中的SQL注入
      跟日常的SQL注入没有本质的区别，就是构造payload的地点改成X-Forwarded-For头了，所以在这就不多做介绍，而且一般都用sqlmap或AVWS程序自动扫描，并告知漏洞点，所以了解就行。不过我做过的这类题貌似都是盲注，所以下面给出python构造报文代码（不是payload）

      ```python
      import sys, httplib, urllib, random 
      params = "value=xxx" 
      ipAddress = "10.0.0.1" 
      headers = {
      "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", 
          "Accept-Encoding":"gzip, deflate", 
          "Accept-Language":"zh-cn,zh;q=0.8,en-us;q=0.5,en;q=0.3", 
          "Connection":"keep-alive", 
          "X-Forwarded-For":ipAddress, 
          "Content-Length":"31", 
          "Content-Type":"application/x-www-form-urlencoded", 
          "User-Agent":"Mozilla/5.0 (Windows NT 5.1; rv:11.0) Gecko/20100101 Firefox/11.0" 
      } 
      con2 = httplib.HTTPConnection("10.0.0.2") 
      try: con2.request("POST", "/xxx.php", params, headers) 
          except Exception, e: print e 
      sys.exit(1) 
      r2 = con2.getresponse() 
      print r2.read() 
      ```



