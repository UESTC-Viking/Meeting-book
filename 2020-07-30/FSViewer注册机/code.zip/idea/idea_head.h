#ifndef _IDEA_H_
#define _IDEA_H_

#include <Windows.h>
#include <stdlib.h>

void IDEAEncrypt(unsigned char *orgData, int lenData);//明文8个字节
void IDEAExtendKey(unsigned char *key);//密钥长度16个字节

#endif