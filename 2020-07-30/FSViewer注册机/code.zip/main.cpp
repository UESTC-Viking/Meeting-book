#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

// crypt head
#include "sha1\sha1_head.h"
#include "blowfish\blowfish_head.h"
#include "sha512\sha512_head.h"
#include "idea\idea_head.h"
#include "base64\base64_head.h"

#define MAX_NAME 20

struct LICENSE
{
    int type; // 0 for Singel User, 1 for Multiple User, 2 for Corporate Site, 3 for Corporate Worldwide
    char regiCode[23+1];
};

void upperCase(char str[])
{
    for (int i = 0; i < strlen(str); i++)
    {
        if (str[i]>=0x61 && str[i]<=0x7A) // in [a,z]
        {
            str[i] -= 0x20;
        }
    }
}

void randomStr(char str[], struct LICENSE *license)
{
    for (int i = 0; i < 8; i++)
    {
        str[i] = (rand()%26)+65; // 随机产生[A,Z]
    }
    
    int flags[4] = {str[3]-77, str[7]-68, str[5]-73, str[1]-79};

    switch (license->type)
    {
    case 0: // res < 0
        if (flags[0]>0 && flags[1]>0 && flags[2]>0 && flags[3]>0)
            str[1] = (rand()%14)+65; // <79
        break;
    case 1: // [1,4998]
        str[3] = (rand()%5)+77; // [77, 81]
        str[7] = (rand()%10)+68; // [68, 77]
        str[5] = (rand()%10)+73; // [73, 82]
        str[1] = (rand()%8)+80; // [80, 87]
        break;
    case 2: // res = 4999
        str[3] = 77+4;
        str[7] = 68+9;
        str[5] = 73+9;
        str[1] = 79+9;
        break;
    case 3: // res >= 5000
        str[3] = (rand()%9)+82; // [82, 90]
        str[7] = (rand()%23)+68; // [68, 90]
        str[5] = (rand()%18)+73; // [73, 90]
        str[1] = (rand()%12)+79; // [79, 90]
        break;
    default:
        printf("Error type\n");
        str[1] = 78; // singel user
        break;
    }
}

void mixStr(char name[], char regiCode[], char mixRes[])
{
    int lenName = strlen(name);
    if (lenName > 8)
    {
        for (int i = 0; i < 8; i++)
        {
            mixRes[i*2] = name[i];
            mixRes[i*2+1] = regiCode[i];
        }
        memcpy(mixRes+2*8, name+8, lenName-8);
        
    }
    else
    {
        for (int i = 0; i < lenName; i++)
        {
            mixRes[i*2] = name[i];
            mixRes[i*2+1] = regiCode[i];
        }
        memcpy(mixRes+2*lenName, regiCode+lenName, 8-lenName);
    }
}

void getUpStr(char str[], int count, char out[])
{
    int i = 0;
    for (int index = 0; i < count ;index++)
    {
        if (str[index]>=0x41 && str[index]<=0x5A)
        {
            out[i] = str[index];
            i++;
        }
    }
}

int main(int argc, char const *argv[])
{
    LICENSE license = {0};
    license.type = 0;
    char fir8[8+1] = {0,}, mid8[8+1] = {0,}, fin4[4+1] = {0,}, name[MAX_NAME] = "Viking";
    char mixCode[MAX_NAME+8+1] = {0,};
    // input
    printf("[0.Singel User 1.Multiple User 2.Corporate Site 3.Corporate Worldwide]\n");
    printf("->Choose Type: ");
    scanf("%d", &license.type);
    printf("->Enter name: ");
    scanf("%s", name);
    // init
    upperCase(name);
    srand(time(0));
    randomStr(fir8, &license);    // generate first 8 code
    mixStr(name, fir8, mixCode);

    // generate middle 8 code
    unsigned char encodeStr[122] = "me4T6cBLV";
    strcat((char*)encodeStr, fir8);
    strcat((char*)encodeStr, "CpCwxrvCJZ30pKLu8Svxjhnhut437glCpofVssnFeBh2G0ekUq4VcxFintMix52vL0iJNbdtWqHPyeumkDUC+4AaoSX+xpl56Esonk4=");
    unsigned char sha1Res[20] = {0,};
    SHA1Encrypt(encodeStr, strlen((char*)encodeStr), sha1Res);
    //sha1->encodeStr, hash value as blowfish's cipher to init s,p_box
    Bf_ExchangeBox(sha1Res, 20);

    memset(encodeStr, 0, 122);
    strcpy((char*)encodeStr, fir8);
    strcat((char*)encodeStr, "96332");
    strcat((char*)encodeStr, mixCode);
    unsigned char sha512Res[64];
    SHA512Encrypt(encodeStr, strlen((char*)encodeStr), sha512Res);
    //sha512->encodeStr,hash value as idea's cipher to init
    IDEAExtendKey(sha512Res);

    BYTE var[8] = {0}, result[40] = {0}, base64Res[60] = {0};
    //blowfish+xor+base64
    unsigned char data[] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
    Bf_Encrypt(data, sizeof(data));
	memcpy(var, data, 8);
	for (int i = 0; i < strlen(mixCode); ++i)
	{
		Bf_Encrypt(data,  sizeof(data));
		BYTE tmp = data[0]^mixCode[i];
		result[i] = tmp;
		memcpy(&var[0], &var[1], 7);
		var[7] = tmp;
		memcpy(data, var, 8);
	}	
    base64_encode(result, strlen(mixCode), base64Res);
    //idea+xor+base64
    memset(data, 0, sizeof(data)); memset(result, 0, sizeof(result));
    IDEAEncrypt(data, sizeof(data));
    memcpy(var, data, 8);
	for (int i = 0; i < strlen((char*)base64Res); ++i)
	{
		IDEAEncrypt(data,  sizeof(data));
		BYTE tmp = data[0]^base64Res[i];
		result[i] = tmp;
		memcpy(&var[0], &var[1], 7);
		var[7] = tmp;
		memcpy(data, var, 8);
	}	
    base64_encode(result, strlen((char*)base64Res), base64Res);
    //get the second part of code
    getUpStr((char*)base64Res, 8, mid8);
    
    // generate final 4 code
    unsigned char msg[] = "09232849248398340903834873297239340547237623242043324398489390309284343843223493299435";
    SHA512Encrypt(msg, strlen((char*)msg), sha512Res);
    Bf_ExchangeBox(sha512Res, 56); // blowfish's cipher length in [4,56]
    SHA1Encrypt(encodeStr, strlen((char*)encodeStr), sha1Res); // var 'encodeStr' not be changed is also: fir8+96332+mixCode
    IDEAExtendKey(sha1Res);
    //loop idea
    memset(data, 0, sizeof(data)); memset(result, 0, sizeof(result));
    int count = fir8[0] - 0x32;
	if (count >= 0)
	{
        IDEAEncrypt(data, sizeof(data));
        memcpy(var, data, 8);
		count += 1;
		for (int i = 0; i < count; ++i)
		{
	        for (int j = 0; j < strlen((char*)mixCode); ++j)
	        {
		        IDEAEncrypt(data,  sizeof(data));
		        BYTE tmp = data[0]^mixCode[j];
		        result[j] = tmp;
		        memcpy(&var[0], &var[1], 7);
		        var[7] = tmp;
		        memcpy(data, var, 8);
	        }
		}
        base64_encode(result, strlen((char*)mixCode), base64Res);
	}
    else
    {
        printf("Error\n");
        return 1;
    }
    //blowfish+xor+base64
    memset(data, 0, sizeof(data));
    Bf_Encrypt(data, sizeof(data));
	memcpy(var, data, 8);
	for (int i = 0; i < strlen((char*)base64Res); ++i)
	{
		Bf_Encrypt(data,  sizeof(data));
		BYTE tmp = data[0]^base64Res[i];
		result[i] = tmp;
		memcpy(&var[0], &var[1], 7);
		var[7] = tmp;
		memcpy(data, var, 8);
	}	
    base64_encode(result, strlen((char*)base64Res), base64Res);

    //get the third part of code
    getUpStr((char*)base64Res, 4, fin4);

    // print
    memcpy(license.regiCode, fir8, 5);
    strcat(license.regiCode, "-");
    strcat(license.regiCode, (fir8+5));
    memcpy(license.regiCode+9, mid8, 2);
    strcat(license.regiCode, "-");
    memcpy(license.regiCode+12, (mid8+2), 5);
    strcat(license.regiCode, "-");
    strcat(license.regiCode, (mid8+7));
    strcat(license.regiCode, fin4);
    printf("[RegisterCode: %s]\n", license.regiCode);

    return 0;
}
