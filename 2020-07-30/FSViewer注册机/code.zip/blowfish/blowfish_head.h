#ifndef BLOWFISH_H
#define BLOWFISH_H

#include <stdio.h>
#include <windows.h>

void Bf_ExchangeBox(BYTE *key, int lenKey);
void Bf_Encrypt(BYTE *data, int lenData);

#endif