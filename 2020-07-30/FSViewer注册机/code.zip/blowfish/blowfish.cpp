#include "s_p_box.h"
#include "blowfish_head.h"

//blow的密钥长度为动态的  64bit - 448bit
//blowfish有两个盒 unsigned long pbox[18] 和 unsigned long sbox[4][256] 总计是4168个字节 
/*
算法流程如下
1.根据key对 p_box 和 s_box 进行变换
	1.1 用π的小数部分填充p_box和s_box 这里在文件头中已经给出
	1.2用key 以每64bit为一个单位 进行异或操作，当密钥不足的时候可以轮用密钥
	1.2 用BF_Fn函数加密一个全0的64bit信息
	1.3输出的64位填充到pBox和sBox
	2.加密密文每64bit(8字节)
	2.1将64bit 拆成左右32bit
	2.2进行BF_Fn()变换
*/

unsigned long p_box[18] = {0};
unsigned long s_box[4][256] = {0};

void SPBoxInit()
{
	memcpy(p_box, org_p_box, 4*18);
	memcpy(s_box, org_s_box, 4*4*256);
}

ULONG SearchTable(ULONG leftPart)
{
	ULONG value;
	
	//查表操作 每一个字节查一次表 然后进行加和异或操作
	value = s_box[0][leftPart >> 24] + s_box[1][(leftPart >> 16) & 0xff];
	value ^= s_box[2][(leftPart >> 8) & 0xff];
	value += s_box[3][leftPart & 0xff];

	return value;
}
//BlowFish的主加密函数 它对明文的加密和对密钥的变换都是利用这个 迭代变换16轮
inline void BF_Fn(ULONG &leftPart, ULONG &rightPart)
{
	int i;

	for (i = 0; i < 16; i += 2) {
		leftPart ^= p_box[i];
		rightPart ^= SearchTable(leftPart);
		rightPart ^= p_box[i + 1];
		leftPart ^= SearchTable(rightPart);
	}

	leftPart ^= p_box[16];
	rightPart ^= p_box[17];

	//最后交换一下
	ULONG temp = leftPart;
	leftPart = rightPart;
	rightPart = temp;

}

//对pBox和sBox进行变换
void Bf_ExchangeBox(BYTE *key, int lenKey)
{
	SPBoxInit(); // 初始化s_p_box

	int i, j;
	int keyLen = lenKey;//获取key长度
	if (keyLen>56)
		keyLen = 56;
	ULONG *keyLong = NULL;
	ULONG leftPart = 0, rightPart = 0;//得到共计64bit的左右两部分
	keyLong = (ULONG *)malloc(keyLen * sizeof(byte));//获取应得的空间
	ZeroMemory(keyLong, keyLen * sizeof(byte));
	keyLen = keyLen / sizeof(ULONG);
	
	//printf("KeyLen : %d\n",keyLen);
	//printf("Key : ");
	for (i = 0; i < keyLen ; i++) {
		keyLong[i] = _byteswap_ulong(*((ULONG *)key + i));
		//printf("0x%x\t", keyLong[i]);
	}
	//printf("\n");
	
	for (i = 0; i < 18; i++) {//进行异或
		p_box[i] ^= keyLong[i % keyLen];
	}

	leftPart = rightPart = 0;//产生一个64位全0数据
	for (i = 0; i < 18; i += 2) {//变换pBox
		BF_Fn(leftPart, rightPart);
		p_box[i] = leftPart;
		p_box[i + 1] = rightPart;
	}

	for (i = 0; i < 4; i++) {//变换sBox
		for (j = 0; j < 256; j += 2) {//256 / 2 == 128
			BF_Fn(leftPart, rightPart);
			s_box[i][j] = leftPart;
			s_box[i][j + 1] = rightPart;
		}
	}
}

//进行加密明文
void Bf_Encrypt(BYTE *data, int lenData)
{
	int i;
	int dataLen = lenData / (sizeof(ULONG) * 2);//获取data长度
	BYTE *dataCopy = data;//建立一个data副本 方便进行指针偏移
	ULONG leftPart, rightPart;
	
	//至此就可以加密明文了 一次加密2 * 4字节大小
	for (i = 0; i < dataLen; i++) {
		leftPart = _byteswap_ulong(*((ULONG *)dataCopy));
		rightPart = _byteswap_ulong(*((ULONG *)dataCopy + 1));
		BF_Fn(leftPart,rightPart);
		*((ULONG *)dataCopy) = _byteswap_ulong(leftPart);
		*((ULONG *)dataCopy + 1) = _byteswap_ulong(rightPart);
		dataCopy += sizeof(ULONG) * 2;//指向下一个数据块
	}
	
}
