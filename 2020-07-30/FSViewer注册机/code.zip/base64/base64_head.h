
/*base64.h*/  
#ifndef _BASE64_H  
#define _BASE64_H  
  
#include <stdlib.h>   
#include <stdint.h>
#include <string.h>
  
int base64_encode(unsigned char *in, int inlen, uint8_t *out);
int base64_decode(char *in, int inlen, uint8_t *out);
  
#endif