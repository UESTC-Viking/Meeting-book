##简单的安卓逆向
>因为最近在看安卓开发,这个东西有点多,没法系统的分享
就以一个简单的安卓逆向来分享,会涉及一点点安卓知识

**一个未加壳也没调用so加密的简单切水果游戏**

在开始游戏时会提示购买,目标就是过掉支付
![buy](buy.jpg)
之后会提示支付失败
![pay](pay.jpg)

用Android killer载入apk
(Android killer集成了apktools和dex2jar以及jd-gui就不用一个一个下载再使用了,非常好用)

因为提示了支付失败,就搜索一下失败的字符串:
![fail](fail.jpg)

定位到关键smali(相当于class的反编译文件)
![key](key.jpg)

查看对应的Java反编译代码:
(关键方法)
![key_java](key_java.jpg)

**找一下方法的交叉引用,找一下上下文,看一看payFalse是怎么被调用的,捋一下逻辑的话,看smali汇编,这有一个方法,先进行判断,然后调用paySuccess否则payFalse**
很显然将判断删掉就好
或者在判断前加一个goto语句让方法直接跳到paySuccess处
![if](if.jpg)

改一下app名字:
![name](name.jpg)

然后在模拟器路径下找到adb_server,开个端口(adb connect 127.0.0.1:5037)
让Android killer连接上模拟器,编译,安装(不连也行就是得手动安装了)
(效果):
![success](success.jpg)
