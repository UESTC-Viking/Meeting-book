runnable jar file
environment: no less than Java8