#[ 辅助算法实现 ]
>上次分享了dll注入,这次分享辅助具体的实现
--------------------
## 1. 流程
<div style="width:400px;">
<div style="float:left; clear: both;" align="center">
<img src="lc.jpg" width="120" alt="" hspace="8"><br /> 流程图</div>
1.注入dll文件<br></br>
2.dll新开一个控制台窗口<br></br>
3.读取地图数据<br></br>
4.寻找可相消的块<br></br>
5.计算坐标并PostMessage
</div>
<br><br><br><br><br></br></br></br></br></br>

---------------------
## 2. 读取地图数据
>**经过分析，地图数据在内存中是从**0x18BB50**开始的(不是确定的[hook])**
**然后前八个字节一定是**0xDC,0x00,0x00,0x00,0x00,0x00,0x00,0x00
**后**0xD1**个数据才是真正的地图数据:**

![odmap](odmap.jpg)
```C++
int FindMapData()
{
    OutputDebugString("开始寻址");
    unsigned char dc=0;
    if(!ReadProcessMemory(hProcess,(PCVOID)MapAddr,&dc,1,NULL)){
        DWORD errorcode = GetLastError();
        OutputDebugPrintf("ReadProcessMemory1失败[ErrorCode: %u]",errorcode);
        return -1;
    }
    else{
        if(dc!=0xDC)
            OutputDebugString("Mapbase address may be wrong");
    }

    if(!ReadProcessMemory(hProcess,(PCVOID)(MapAddr+0x8),map,209,NULL)){
        DWORD errorcode = GetLastError();
        OutputDebugPrintf("ReadProcessMemory2失败[ErrorCode: %u]",errorcode);
        return -1;
    }
    PrintMap();
    return 0;
}
```
--------------
## 3. 寻路算法实现
**基本相消规则:**
![llkal](llkal.jpg)
```C++
//水平相消判断:图A
int horizon(int x1, int y1, int x2, int y2)
{
    if (x1 == x2 && y1 == y2)
    {
        return FALSE;
    }

    if (x1 != x2)
    {
        return FALSE;
    }

    int start_y = y1 < y2 ? y1 : y2; //std::min(y1, y2)
    int end_y = y1 > y2 ? y1 : y2;   //std::max(y1, y2);

    for (int j = start_y + 1; j < end_y; j++)
    {
        if (isBlocked(x1, j))
        {
            return FALSE;
        }
    }

    return TRUE;
}
```
**具体实现:** https://blog.csdn.net/qq_41551359/article/details/82983513
#### 小问题:怎么遍历?
**利用栈**

--------------------
## 4. 模拟鼠标点击
>模拟鼠标点击不能是相对屏幕的,因为游戏窗口不是固定的
+ **获取游戏窗口句柄**
+ **计算相对坐标**
+ **PostMessage API**

### windows的消息机制
>消息，就是指Windows发出的一个通知，告诉应用程序某个事情发生了。例如，单击鼠标、改变窗口尺寸、按下键盘上的一个键都会使Windows发送一个消息给应用程序。<br>

产生一个消息 ----> OS消息队列 ----> 程序消息队列
```C++
while( GetMessage(&msg, NULL, 0, 0) )
{
    TranslateMessage(&msg);
    DispatchMessage(&msg);
}
```
程序从队列中取得消息 ----> 处理消息 ----> 调用相应的消息回调函数

**简单来说就是每个程序都有一个 消息队列 程序会不断的从它的消息队列中获取消息,然后执行相应的操作,那么我们就可以往目标程序的消息队列中放一个鼠标点击(x,y)的消息,那么就相当于我们鼠标点击了(x,y)**

### PostMessage API
```C++
void MouseClick(int a,int b)
{
    printf("A(X,Y):(%d,%d)\n",31*objects[a].y+15+10,35*objects[a].x+17+180);
    PostMessage(hWnd,WM_SETCURSOR,WPARAM(hWnd),MAKELPARAM(HTCLIENT,WM_MOUSEMOVE));
    PostMessage(hWnd,WM_MOUSEMOVE,NULL,MAKELPARAM(31*objects[a].y+15+10,35*objects[a].x+17+180));
    PostMessage(hWnd,WM_LBUTTONDOWN,MK_LBUTTON,MAKELPARAM(31*objects[a].y+15+10,35*objects[a].x+17+180));
    PostMessage(hWnd,WM_LBUTTONUP,NULL,MAKELPARAM(31*objects[a].y+15+10,35*objects[a].x+17+180));
    printf("B(X,Y):(%d,%d)\n",31*objects[b].y+15+10,35*objects[b].x+17+180);
    PostMessage(hWnd,WM_SETCURSOR,WPARAM(hWnd),MAKELPARAM(HTCLIENT,WM_MOUSEMOVE));
    PostMessage(hWnd,WM_MOUSEMOVE,NULL,MAKELPARAM(31*objects[b].y+15+10,35*objects[b].x+17+180));
    PostMessage(hWnd,WM_LBUTTONDOWN,MK_LBUTTON,MAKELPARAM(31*objects[b].y+15+10,35*objects[b].x+17+180));
    PostMessage(hWnd,WM_LBUTTONUP,NULL,MAKELPARAM(31*objects[b].y+15+10,35*objects[b].x+17+180));
}
```











