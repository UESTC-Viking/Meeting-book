#include <stdio.h>
#include "main.h"

#define LINE 11
#define ROW 19

typedef struct
{
    int x;
    int y;
    unsigned char type;
} OBJECTS;

unsigned char map[LINE][ROW]={0};
OBJECTS objects[LINE * ROW]={0,0,0};
int count = 0;

DWORD Pid = 0;
HANDLE hProcess = 0;
HWND hWnd = 0;
DWORD MapAddr = 0x18BB50;

void OutputDebugPrintf(const char * strOutputString,...)
{
    char strBuffer[4096]={0};
    va_list vlArgs;
    va_start(vlArgs,strOutputString);
    _vsnprintf(strBuffer,sizeof(strBuffer)-1,strOutputString,vlArgs);
    //vsprintf(strBuffer,strOutputString,vlArgs);
    va_end(vlArgs);
    OutputDebugString(strBuffer);
}

int isBlocked(int x, int y)
{
    if (map[x][y] != 0x00)
        return 1; //have block
    else
        return 0;
}

int horizon(int x1, int y1, int x2, int y2)
{
    if (x1 == x2 && y1 == y2)
    {
        return FALSE;
    }

    if (x1 != x2)
    {
        return FALSE;
    }

    int start_y = y1 < y2 ? y1 : y2; //std::min(y1, y2)
    int end_y = y1 > y2 ? y1 : y2;   //std::max(y1, y2);

    for (int j = start_y + 1; j < end_y; j++)
    {
        if (isBlocked(x1, j))
        {
            return FALSE;
        }
    }

    return TRUE;
}

int vertical(int x1, int y1, int x2, int y2)
{
    if (x1 == x2 && y1 == y2)
    {
        return FALSE;
    }

    if (y1 != y2)
    {
        return FALSE;
    }

    int start_x = x1 < x2 ? x1 : x2; //std::min(x1, x2);
    int end_x = x1 > x2 ? x1 : x2;   //std::max(x1, x2);

    for (int i = start_x + 1; i < end_x; i++)
    {
        if (isBlocked(i, y1))
        {
            return FALSE;
        }
    }

    return TRUE;
}

int turn_once(int x1, int y1, int x2, int y2)
{
    if (x1 == x2 && y1 == y2)
    {
        return FALSE;
    }

    int c_x = x1, c_y = y2;
    int d_x = x2, d_y = y1;

    int ret = FALSE;
    if (!isBlocked(c_x, c_y))
    {
        ret |= (horizon(x1, y1, c_x, c_y) && vertical(c_x, c_y, x2, y2));
    }

    if (!isBlocked(d_x, d_y))
    {
        ret |= (horizon(x1, y1, d_x, d_y) && vertical(d_x, d_y, x2, y2));
    }
    if (ret)
    {
        return TRUE;
    }

    return FALSE;
}

int turn_twice(int x1, int y1, int x2, int y2)
{
    if (x1 == x2 && y1 == y2)
    {
        return FALSE;
    }

    for (int i = 0; i < LINE; i++)
    {
        for (int j = 0; j < ROW; j++)
        {
            if ((i != x1 && i != x2) && (j != y1 && j != y2))
            {
                continue;
            }

            if ((i == x1 && j == y1) || (i == x2 && j == y2))
            {
                continue;
            }

            if (isBlocked(i, j))
            {
                continue;
            }

            if (turn_once(x1, y1, i, j) && (horizon(i, j, x2, y2) || vertical(i, j, x2, y2)))
            {
                return TRUE;
            }
            if (turn_once(i, j, x2, y2) && (horizon(x1, y1, i, j) || vertical(x1, y1, i, j)))
            {
                return TRUE;
            }
        }
    }

    return FALSE;
}

int ismove(int x1, int y1, int x2, int y2)
{
    int ret = FALSE;

    ret = horizon(x1, y1, x2, y2);
    if (ret)
    {
        return TRUE;
    }
    ret = vertical(x1, y1, x2, y2);
    if (ret)
    {
        return TRUE;
    }
    ret = turn_once(x1, y1, x2, y2);
    if (ret)
    {
        return TRUE;
    }
    ret = turn_twice(x1, y1, x2, y2);
    if (ret)
    {
        return TRUE;
    }

    return FALSE;
}

void resort(int start1, int start2)
{
    int  fw = 0,bw = 0;
    if(start1 < start2){
        fw = start1;
        bw = start2;
    }else{
        fw = start2;
        bw = start1;
    }

    for (int i = fw; i < bw-1; i++)
    {
        objects[i] = objects[i+1];
    }
    for (int i = bw-1; i < count-2; i++)
    {
        objects[i] = objects[i+2];
    }

}

void MouseClick(int a,int b)
{
    printf("A(X,Y):(%d,%d)\n",31*objects[a].y+15+10,35*objects[a].x+17+180);
    PostMessage(hWnd,WM_SETCURSOR,WPARAM(hWnd),MAKELPARAM(HTCLIENT,WM_MOUSEMOVE));
    PostMessage(hWnd,WM_MOUSEMOVE,NULL,MAKELPARAM(31*objects[a].y+15+10,35*objects[a].x+17+180));
    PostMessage(hWnd,WM_LBUTTONDOWN,MK_LBUTTON,MAKELPARAM(31*objects[a].y+15+10,35*objects[a].x+17+180));
    PostMessage(hWnd,WM_LBUTTONUP,NULL,MAKELPARAM(31*objects[a].y+15+10,35*objects[a].x+17+180));
    printf("B(X,Y):(%d,%d)\n",31*objects[b].y+15+10,35*objects[b].x+17+180);
    PostMessage(hWnd,WM_SETCURSOR,WPARAM(hWnd),MAKELPARAM(HTCLIENT,WM_MOUSEMOVE));
    PostMessage(hWnd,WM_MOUSEMOVE,NULL,MAKELPARAM(31*objects[b].y+15+10,35*objects[b].x+17+180));
    PostMessage(hWnd,WM_LBUTTONDOWN,MK_LBUTTON,MAKELPARAM(31*objects[b].y+15+10,35*objects[b].x+17+180));
    PostMessage(hWnd,WM_LBUTTONUP,NULL,MAKELPARAM(31*objects[b].y+15+10,35*objects[b].x+17+180));
}

int start(int ytime)
{
    count = 0;
    for (int i = 0; i < LINE; i++)
    {
        for (int j = 0; j < ROW; j++)
        {
            if (map[i][j] == 0x00)
            {
                continue;
            }
            else
            {
                objects[count].x = i;
                objects[count].y = j;
                objects[count].type = map[i][j];
                count++;
            }
        }
    }
    printf("Count:%d\n\n",count);

    int sp = 0, flag = 0;
    while (objects[0].type != 0x00)
    {
        //printf("\n[Current sp: %d]\n",sp);
        flag = 0;
        for (int i = 0; i < count; i++)
        {
            if ((objects[sp].type != objects[i].type) || (sp == i))
                continue;
            else
            {
                int x1 = objects[sp].x, y1 = objects[sp].y;
                int x2 = objects[i].x, y2 = objects[i].y;
                if (ismove(x1,y1,x2,y2)){
                    printf("sp:%d,i:%d\n",sp,i);
                    printf("Move (%x,%x):%02x | (%x,%x):%02x\n",x1,y1,objects[sp].type,x2,y2,objects[i].type);
                    MouseClick(sp,i);
                    objects[sp].type=0;objects[i].type=0;
                    map[x1][y1]=0;map[x2][y2]=0;
                    resort(sp,i);
                    count -= 2;
                    printf("Count:%d\n\n",count);
                    if(sp!=0)
                        sp--;
                    flag = 1;
                    Sleep(ytime);
                    break;
                }
            }
        }
        if(flag == 0)
            sp++;
    }

    return 0;
}

void PrintMap()
{
    printf("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n");
    for(int i=0;i<LINE;i++){
        for(int j=0;j<ROW;j++){
            printf("%02x ",map[i][j]);
        }
        printf("\n");
    }
    printf("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n");
}

int FindMapData()
{
    OutputDebugString("��ʼѰַ");
    unsigned char dc=0;
    if(!ReadProcessMemory(hProcess,(PCVOID)MapAddr,&dc,1,NULL)){
        DWORD errorcode = GetLastError();
        OutputDebugPrintf("ReadProcessMemory1ʧ��[ErrorCode: %u]",errorcode);
        return -1;
    }
    else{
        if(dc!=0xDC)
            OutputDebugString("Mapbase address may be wrong");
    }

    if(!ReadProcessMemory(hProcess,(PCVOID)(MapAddr+0x8),map,209,NULL)){
        DWORD errorcode = GetLastError();
        OutputDebugPrintf("ReadProcessMemory2ʧ��[ErrorCode: %u]",errorcode);
        return -1;
    }
    PrintMap();
    return 0;
}

int CreateConsole()
{
    AllocConsole();
    SetConsoleTitle("����������");
    freopen("CONOUT$", "w", stdout);
    freopen("CONIN$","r",stdin);

    int ytime = 0;

    while(1)
    {
        while(1)
        {
            printf("����f��ʼѰ�ҵ�ͼ����...\n");
            if(getchar()=='f')
            {
                if(FindMapData()!=-1)
                {
                    break;

                }
                else
                    printf("Ѱ������ʧ��,������...\n");
            }
        }

        printf("���뵥���ӳ�[0-4000ms]: ");
        scanf("%d",&ytime);
        getchar();

        if(ytime<0 || ytime>4000)
            ytime = 250;
        OutputDebugPrintf("Ytime: %d",ytime);

        while(1)
        {
            printf("\n����x��ʼ����...\n");
            if(getchar()=='x')
            {
                start(ytime);
                break;
            }
        }
        getchar();//\n
        printf("����q�˳�(�����������������)...\n");
        if(getchar()=='q')
            break;

    }

    CloseHandle(hProcess);
    FreeConsole();
    return 0;
}

extern "C" DLL_EXPORT BOOL APIENTRY DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    switch (fdwReason)
    {
    case DLL_PROCESS_ATTACH:
        Pid = GetCurrentProcessId();
        OutputDebugPrintf("%u",Pid);
        hProcess = OpenProcess(PROCESS_ALL_ACCESS,FALSE,Pid);
        if(!hProcess)
        {
            OutputDebugString("OpenProcess Failed");
            return -1;
        }
        hWnd = FindWindow(NULL,"QQ������");
        if(hWnd == NULL)
        {
            printf("�����ȡ����,��ر�����...\n");
            getchar();
            return TRUE;
        }
        OutputDebugPrintf("HWND:0x%p",hWnd);
        OutputDebugString("C�߳̿�ʼ");
        CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)CreateConsole,NULL,0,NULL);

        // attach to process
        // return FALSE to fail DLL load
        break;

    case DLL_PROCESS_DETACH:
        OutputDebugString("Detach from Process Success!");
        // detach from process
        break;

    case DLL_THREAD_ATTACH:
        // attach to thread
        break;

    case DLL_THREAD_DETACH:
        // detach from thread
        break;
    }
    return TRUE; // succesful
}
