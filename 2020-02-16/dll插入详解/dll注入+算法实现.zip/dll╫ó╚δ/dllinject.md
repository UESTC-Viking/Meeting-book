#[DLL注入]
----------
## 1.什么是dll注入
### 1.1什么是dll
>dll全称Dynamic Link Library即动态链接库,和模块、python库以及linux系统上的共享库这些概念差不多

比如说:
我想封装一个功能,之后直接调用就行,就把该函数可以写入dll文件
**DLL**:
```
char* PyToC(char *code)
{
    ......
}
```
**其他程序**:
```
先加载dll文件
然后
char Pcode[] = "...", Ncode[MAX_C];
strcpy(Ncode,PytoC(Pcode));
直接调用即可
```
### 1.2什么是dll注入
>写程序的时候会将需要的dll链接起来,这样程序启动的时候会自动加载所需要的dll

**dll注入就是让目标程序加载我们写的dll文件(本不会加载该dll)**

---------
## 2.为什么要dll注入
>* 通过dll注入我们可以给原程序添加他所没有的功能,
>* 同时因为目标程序加载了我们的dll,所以我们的dll就会与目标程序共享同一个内存空间,就可以进行一些高权限操作了

**比如说:**
**&ensp; &ensp; 目标程序可以从特定网页爬取图片,但是没有提供下载功能,那么我们可以将下载功能写入我们的dll,然后把dll注入到目标程序,然后修改目标程序内存,让程序每次爬取图片时先调用我们dll中的下载函数,再call 原函数**

-------
## 3.如何进行dll注入
* 利用消息钩子
* 修改PE头
* **利用CreateRemoteThread函数**
* 修改注册表
* ~~输入法注入~~
..........

###3.1dll加载方式
>dll可以通过静态编译,也可以通过动态加载来调用

静态编译就是在编译的时候就将函数、索引等信息和程序链接
动态加载就是在程序中没有dll的信息,通过Loadlibrary等函数动态加载dll，然后用函数指针去调用dll中的函数
那么我们就可以让目标程序去调用LoadLibrary("MyDll.dll")来让目标程序加载我们的dll

那么怎么让目标程序调用loadlibrary呢？
###3.2创建远程线程
微软给我们提供了非常好使的API,
**CreateRemoteThread**
>Creates a thread that runs in the virtual address space of another process.
Use the CreateRemoteThreadEx function to create a thread that runs in the virtual address space of another process and optionally specify extended attributes. 
&ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; --Microsoft
```
HANDLE CreateRemoteThread(
  HANDLE                 hProcess,
  LPSECURITY_ATTRIBUTES  lpThreadAttributes,
  SIZE_T                 dwStackSize,
  LPTHREAD_START_ROUTINE lpStartAddress,
  LPVOID                 lpParameter,
  DWORD                  dwCreationFlags,
  LPDWORD                lpThreadId
);
```
就是会在目标程序进程空间中创建一个线程
###3.3注入前的准备
让目标程序开一个线程调用Loadlibrary()
但该函数需要传入一个参数(DLL路径)
**这个字符串应该在目标程序的内存空间中**
```
char *dllpath = "C:\\Admin\\Desktop\\MyDll.dll";
HANDLE moudleloadlibrary = GetProcAddr(...);
CreateRemoteThread(
                    hProcess,
                    NULL,
                    0,
                    (LPTHREAD_START_ROUTINE)moudleloadlibrary,
                    dllpath,
                    0,
                    NULL);
```
**↑这样写是不对的↑**
+ 用**VirtualAllocEx**在目标程序中申请一块内存
+ 在**WriteProcessMemory**将字符串数据写入到目标程序内存空间中

![VirtualAllocEx](va.jpg)

![WriteProcessMemory](wpm.jpg)

###3.4地址问题
>要创建远程线程我们需要知道Loadlibrary函数在目标程序中的地址

**微软设计的时候就规定系统dll加载的基址不变**
比如说：
一个程序加载了很多的dll
![dll](dll.jpg)
他自己的dll基址可能每次加载都不同(重定位)
但是程序运行所需的系统dll(每个程序都会加载)的基址一定不变且每个程序都相同
**且几乎所有程序都会加载Kernel32.dll,而Loadlibrary函数就在这个dll中**
这是能够找到loadlibrary函数地址的原因(找自己程序的地址就行)

###3.5加载后运行问题
>dll被注入到目标程序,但是目标程序并没有调用我们dll中的函数?

![dllmain](dllmain.jpg)
dll的入口是DllMain
当dll被加载时会自动调用
case DLL_PROCESS_ATTACH:
下的函数,我们把需要**首先**调用的函数写到这个case下就行
